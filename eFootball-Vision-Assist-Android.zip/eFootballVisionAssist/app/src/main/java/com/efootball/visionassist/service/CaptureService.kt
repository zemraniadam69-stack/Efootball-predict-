package com.efootball.visionassist.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.efootball.visionassist.MainActivity
import com.efootball.visionassist.R
import com.efootball.visionassist.network.ModelDownloader
import com.efootball.visionassist.vision.VisionPipeline
import kotlinx.coroutines.*
import java.nio.ByteBuffer
import java.util.concurrent.ArrayBlockingQueue

class CaptureService : Service() {

    companion object {
        const val NOTIFICATION_CHANNEL_ID = "efootball_capture_channel"
        const val NOTIFICATION_ID = 1001
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val CAPTURE_WIDTH = 1280
        const val CAPTURE_HEIGHT = 720

        var activePipeline: VisionPipeline? = null
            private set
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val frameRingBuffer = ArrayBlockingQueue<Bitmap>(2)
    private var isRunning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode == 0 || resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundWithNotification()
        initPipelineAndCapture(resultCode, resultData)
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Vision Assist Active")
            .setContentText("60 FPS pitch and pass analysis running")
            .setSmallIcon(R.drawable.ic_vision_hud)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initPipelineAndCapture(resultCode: Int, resultData: Intent) {
        val modelDownloader = ModelDownloader(this)
        val modelFile = modelDownloader.getModelFile()
        activePipeline = VisionPipeline(applicationContext, modelFile)

        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getRealMetrics(metrics)

        imageReader = ImageReader.newInstance(CAPTURE_WIDTH, CAPTURE_HEIGHT, PixelFormat.RGBA_8888, 3)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "eFootballCapture", CAPTURE_WIDTH, CAPTURE_HEIGHT, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, null
        )

        isRunning = true
        startRingBufferConsumer()
        startFrameCaptureListener()
        startService(Intent(this, OverlayService::class.java))
    }

    private fun startFrameCaptureListener() {
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (frameRingBuffer.remainingCapacity() == 0) {
                    frameRingBuffer.poll() // Drop oldest frame (>16ms latency defense)
                }
                val bitmap = imageToBitmap(image)
                if (bitmap != null) {
                    frameRingBuffer.offer(bitmap)
                }
            } finally {
                image.close()
            }
        }, null)
    }

    private fun startRingBufferConsumer() {
        serviceScope.launch(Dispatchers.Default) {
            while (isRunning) {
                try {
                    val frameBitmap = frameRingBuffer.take()
                    activePipeline?.processFrame(frameBitmap)
                } catch (_: InterruptedException) {
                    break
                }
            }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val planes = image.planes
        val buffer = planes[0].buffer
        val bitmap = Bitmap.createBitmap(image.width, image.height, Bitmap.Config.ARGB_8888)
        bitmap.copyPixelsFromBuffer(buffer)
        return bitmap
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        serviceScope.cancel()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        activePipeline?.release()
        activePipeline = null
        stopService(Intent(this, OverlayService::class.java))
    }
}