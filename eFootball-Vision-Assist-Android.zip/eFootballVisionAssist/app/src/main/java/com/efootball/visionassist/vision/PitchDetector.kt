package com.efootball.visionassist.vision

import android.graphics.Bitmap
import com.efootball.visionassist.data.PitchPoint
import com.efootball.visionassist.data.ScreenPoint
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

class PitchDetector {

    private val homographyMatrix = Mat(3, 3, CvType.CV_64FC1)
    private val inverseHomographyMatrix = Mat(3, 3, CvType.CV_64FC1)
    private val rgbaMat = Mat()
    private val hsvMat = Mat()
    private val maskMat = Mat()
    private val edgesMat = Mat()
    private val linesMat = Mat()

    init {
        val srcMat = MatOfPoint2f(Point(120.0, 180.0), Point(1160.0, 180.0), Point(1280.0, 700.0), Point(0.0, 700.0))
        val dstMat = MatOfPoint2f(Point(15.0, 5.0), Point(90.0, 5.0), Point(95.0, 63.0), Point(10.0, 63.0))
        val h = Imgproc.getPerspectiveTransform(srcMat, dstMat)
        h.copyTo(homographyMatrix)
        Core.invert(homographyMatrix, inverseHomographyMatrix)
    }

    fun processFrame(bitmap: Bitmap): Boolean {
        Utils.bitmapToMat(bitmap, rgbaMat)
        Imgproc.cvtColor(rgbaMat, hsvMat, Imgproc.COLOR_RGB2HSV)
        Core.inRange(hsvMat, Scalar(0.0, 0.0, 180.0), Scalar(180.0, 65.0, 255.0), maskMat)
        Imgproc.Canny(maskMat, edgesMat, 50.0, 150.0)
        Imgproc.HoughLinesP(edgesMat, linesMat, 1.0, Math.PI / 180, 70, 50.0, 15.0)
        return true
    }

    fun screenToPitch(s: ScreenPoint): PitchPoint {
        val h = DoubleArray(9)
        homographyMatrix.get(0, 0, h)
        val z = h[6] * s.x + h[7] * s.y + h[8]
        val px = if (z != 0.0) ((h[0] * s.x + h[1] * s.y + h[2]) / z).coerceIn(0.0, 105.0) else 0.0
        val py = if (z != 0.0) ((h[3] * s.x + h[4] * s.y + h[5]) / z).coerceIn(0.0, 68.0) else 0.0
        return PitchPoint(px.toFloat(), py.toFloat())
    }

    fun pitchToScreen(p: PitchPoint): ScreenPoint {
        val inv = DoubleArray(9)
        inverseHomographyMatrix.get(0, 0, inv)
        val z = inv[6] * p.x + inv[7] * p.y + inv[8]
        val sx = if (z != 0.0) (inv[0] * p.x + inv[1] * p.y + inv[2]) / z else 0.0
        val sy = if (z != 0.0) (inv[3] * p.x + inv[4] * p.y + inv[5]) / z else 0.0
        return ScreenPoint(sx.toFloat(), sy.toFloat())
    }

    fun release() {
        rgbaMat.release()
        hsvMat.release()
        maskMat.release()
        edgesMat.release()
        linesMat.release()
        homographyMatrix.release()
        inverseHomographyMatrix.release()
    }
}