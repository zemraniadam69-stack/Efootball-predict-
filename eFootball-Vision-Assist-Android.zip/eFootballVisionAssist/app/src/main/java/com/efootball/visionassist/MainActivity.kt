package com.efootball.visionassist

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.efootball.visionassist.data.AssistSettings
import com.efootball.visionassist.network.DownloadStatus
import com.efootball.visionassist.network.ModelDownloader
import com.efootball.visionassist.service.CaptureService
import com.efootball.visionassist.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var modelDownloader: ModelDownloader

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modelDownloader = ModelDownloader(this)

        setContent {
            EFootballVisionAssistTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Slate950
                ) {
                    VisionAssistScreen(
                        modelDownloader = modelDownloader,
                        onStartCaptureService = { resultCode, data ->
                            val intent = Intent(this, CaptureService::class.java).apply {
                                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                startForegroundService(intent)
                            } else {
                                startService(intent)
                            }
                        },
                        onStopCaptureService = {
                            stopService(Intent(this, CaptureService::class.java))
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun VisionAssistScreen(
    modelDownloader: ModelDownloader,
    onStartCaptureService: (resultCode: Int, data: Intent) -> Unit,
    onStopCaptureService: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var hasMediaProjectionPermission by remember { mutableStateOf(false) }
    var mediaProjectionData by remember { mutableStateOf<Pair<Int, Intent>?>(null) }
    var isAssistActive by remember { mutableStateOf(CaptureService.activePipeline != null) }

    var lineThickness by remember { mutableFloatStateOf(6.0f) }
    var showOpponents by remember { mutableStateOf(true) }
    var showPassLines by remember { mutableStateOf(true) }

    val downloadStatus by modelDownloader.downloadStatus.collectAsState()
    val isModelReady = remember(downloadStatus) { modelDownloader.isModelReady() }

    val projectionManager = remember {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    val capturePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            hasMediaProjectionPermission = true
            mediaProjectionData = Pair(result.resultCode, result.data!!)
            Toast.makeText(context, "Screen capture granted", Toast.LENGTH_SHORT).show()
        } else {
            hasMediaProjectionPermission = false
            mediaProjectionData = null
            Toast.makeText(context, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // App Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("eFootball Vision Assist", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("Real-time AI Overlay for jp.konami.pesam", style = MaterialTheme.typography.bodyMedium, color = Slate400)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isAssistActive) Emerald500.copy(alpha = 0.2f) else Slate800)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isAssistActive) "ACTIVE" else "STANDBY",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = if (isAssistActive) Emerald400 else Slate400
                )
            }
        }

        // Section 1: Model Setup
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Slate900)
                .border(1.dp, Slate800, RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("YOLOv8n Neural Weights", style = MaterialTheme.typography.titleMedium, color = Color.White)
            if (isModelReady) {
                Text("Model Ready (yolov8n.tflite)", color = Emerald400, fontSize = 13.sp)
            } else {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            modelDownloader.checkOrDownloadModel(forceRedownload = true)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan500)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Download Model (YOLOv8n)")
                }
            }
        }

        // Section 2: Permissions
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Slate900)
                .border(1.dp, Slate800, RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Permissions", style = MaterialTheme.typography.titleMedium, color = Color.White)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Overlay Window", color = Slate300)
                if (hasOverlayPermission) {
                    Text("Granted", color = Emerald400, fontWeight = FontWeight.Bold)
                } else {
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            context.startActivity(intent)
                        }
                    ) { Text("Grant Overlay") }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Screen Capture", color = Slate300)
                if (hasMediaProjectionPermission) {
                    Text("Granted", color = Emerald400, fontWeight = FontWeight.Bold)
                } else {
                    Button(
                        onClick = { capturePermissionLauncher.launch(projectionManager.createScreenCaptureIntent()) },
                        colors = ButtonDefaults.buttonColors(containerColor = Slate800)
                    ) { Text("Grant Capture") }
                }
            }
        }

        // Section 3: Start / Stop Assist
        val canStart = isModelReady && hasOverlayPermission && hasMediaProjectionPermission
        Button(
            onClick = {
                if (isAssistActive) {
                    onStopCaptureService()
                    isAssistActive = false
                } else {
                    mediaProjectionData?.let { (code, data) ->
                        onStartCaptureService(code, data)
                        isAssistActive = true
                    }
                }
            },
            enabled = isAssistActive || canStart,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isAssistActive) Red500 else Emerald500
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(if (isAssistActive) "STOP VISION ASSIST" else "START VISION ASSIST", fontWeight = FontWeight.Bold)
        }

        // Section 4: Sliders
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Slate900)
                .border(1.dp, Slate800, RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Settings", style = MaterialTheme.typography.titleMedium, color = Color.White)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Line Thickness", color = Slate300)
                Text("${lineThickness.toInt()} px", color = Cyan400, fontFamily = FontFamily.Monospace)
            }
            Slider(value = lineThickness, onValueChange = { lineThickness = it }, valueRange = 2f..14f)

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Show Opponents", color = Slate300)
                Switch(checked = showOpponents, onCheckedChange = { showOpponents = it })
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Show Pass Lines", color = Slate300)
                Switch(checked = showPassLines, onCheckedChange = { showPassLines = it })
            }
        }
    }
}