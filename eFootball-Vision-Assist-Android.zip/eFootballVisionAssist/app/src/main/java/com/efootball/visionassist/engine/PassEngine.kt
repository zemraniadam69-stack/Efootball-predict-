package com.efootball.visionassist.engine

import com.efootball.visionassist.data.*
import kotlin.math.*

class PassEngine {

    fun calculateBestPasses(
        ball: DetectedBall,
        teammates: List<DetectedPlayer>,
        opponents: List<DetectedPlayer>
    ): List<PassOption> {
        val passerPos = ball.pitchPosition
        val validCandidates = teammates.filter {
            it.role == PlayerRole.TEAMMATE && it.pitchPosition.distanceTo(passerPos) in 2.5f..55.0f
        }
        if (validCandidates.isEmpty()) return emptyList()

        return validCandidates.map { teammate ->
            evaluatePassToTeammate(ball, teammate, opponents)
        }.sortedByDescending { it.score }.take(3).mapIndexed { idx, opt -> opt.copy(rank = idx + 1) }
    }

    private fun evaluatePassToTeammate(
        ball: DetectedBall,
        teammate: DetectedPlayer,
        opponents: List<DetectedPlayer>
    ): PassOption {
        val startPitch = ball.pitchPosition
        val targetPitch = teammate.pitchPosition
        val passLength = startPitch.distanceTo(targetPitch)

        var minClearance = Float.MAX_VALUE
        var aggregatedRisk = 0.0f

        for (opp in opponents) {
            val (dist, ratio) = distanceToSegment(opp.pitchPosition, startPitch, targetPitch, passLength)
            if (dist < minClearance) minClearance = dist

            if (ratio in 0.05f..0.95f) {
                val proximity = max(0f, 1.0f - (dist / 7.0f))
                aggregatedRisk += proximity * 10.0f
            }
        }

        val finalLaneClearance = if (minClearance == Float.MAX_VALUE) 25.0f else min(minClearance, 30.0f)
        val forwardProgress = targetPitch.x - startPitch.x
        val interceptionRisk = aggregatedRisk.coerceIn(0.0f, 20.0f)

        // Exact Formula:
        val score = (finalLaneClearance * 0.55f) + (forwardProgress * 0.30f) - (interceptionRisk * 0.40f)

        return PassOption(
            rank = 0,
            targetPlayer = teammate,
            startScreen = ball.screenPosition,
            targetScreen = teammate.screenPosition,
            startPitch = startPitch,
            targetPitch = targetPitch,
            laneClearance = finalLaneClearance,
            forwardProgress = forwardProgress,
            interceptionRisk = interceptionRisk,
            score = score
        )
    }

    private fun distanceToSegment(p: PitchPoint, a: PitchPoint, b: PitchPoint, len: Float): Pair<Float, Float> {
        if (len <= 0.001f) return Pair(p.distanceTo(a), 0f)
        val abX = b.x - a.x
        val abY = b.y - a.y
        val t = (((p.x - a.x) * abX) + ((p.y - a.y) * abY)) / (len * len)
        val clampedT = t.coerceIn(0.0f, 1.0f)
        val cx = a.x + clampedT * abX
        val cy = a.y + clampedT * abY
        val dist = sqrt((p.x - cx) * (p.x - cx) + (p.y - cy) * (p.y - cy))
        return Pair(dist, clampedT)
    }
}