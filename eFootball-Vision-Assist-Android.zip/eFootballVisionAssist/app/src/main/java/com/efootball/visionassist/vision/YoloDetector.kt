package com.efootball.visionassist.vision

import android.graphics.Bitmap
import android.graphics.RectF
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.gpu.CompatibilityList
import org.tensorflow.lite.gpu.GpuDelegate
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

data class YoloDetection(val classId: Int, val className: String, val confidence: Float, val boundingBox: RectF)

class YoloDetector(private val modelFile: File, private val labels: List<String>) {

    private var interpreter: Interpreter? = null
    private var gpuDelegate: GpuDelegate? = null
    private val inputByteBuffer = ByteBuffer.allocateDirect(1 * 640 * 640 * 3 * 4).apply { order(ByteOrder.nativeOrder()) }
    private val outputArray = Array(1) { Array(84) { FloatArray(8400) } }
    private val intValues = IntArray(640 * 640)

    init {
        val options = Interpreter.Options()
        val compatList = CompatibilityList()
        if (compatList.isDelegateSupportedOnThisDevice) {
            gpuDelegate = GpuDelegate(compatList.bestOptionsForThisDevice)
            options.addDelegate(gpuDelegate)
        } else {
            options.setNumThreads(4)
        }
        interpreter = Interpreter(modelFile, options)
    }

    fun detect(bitmap: Bitmap, confidenceThreshold: Float = 0.35f): List<YoloDetection> {
        val tflite = interpreter ?: return emptyList()
        val scaled = Bitmap.createScaledBitmap(bitmap, 640, 640, true)
        inputByteBuffer.rewind()
        scaled.getPixels(intValues, 0, 640, 0, 0, 640, 640)

        for (px in intValues) {
            inputByteBuffer.putFloat(((px shr 16) and 0xFF) / 255f)
            inputByteBuffer.putFloat(((px shr 8) and 0xFF) / 255f)
            inputByteBuffer.putFloat((px and 0xFF) / 255f)
        }

        tflite.run(inputByteBuffer, outputArray)
        val matrix = outputArray[0]
        val candidates = mutableListOf<YoloDetection>()

        for (i in 0 until 8400) {
            val personScore = matrix[4][i]
            val ballScore = matrix[36][i]
            val (bestClass, score) = if (personScore >= confidenceThreshold && personScore >= ballScore) {
                Pair(0, personScore)
            } else if (ballScore >= confidenceThreshold) {
                Pair(32, ballScore)
            } else {
                Pair(-1, 0f)
            }

            if (bestClass != -1) {
                val cx = matrix[0][i]
                val cy = matrix[1][i]
                val w = matrix[2][i]
                val h = matrix[3][i]
                val left = ((cx - w / 2f) / 640f).coerceIn(0f, 1f)
                val top = ((cy - h / 2f) / 640f).coerceIn(0f, 1f)
                val right = ((cx + w / 2f) / 640f).coerceIn(0f, 1f)
                val bottom = ((cy + h / 2f) / 640f).coerceIn(0f, 1f)
                candidates.add(YoloDetection(bestClass, if (bestClass == 0) "person" else "sports ball", score, RectF(left, top, right, bottom)))
            }
        }

        return applyNms(candidates, 0.45f)
    }

    private fun applyNms(detections: List<YoloDetection>, iouThreshold: Float): List<YoloDetection> {
        val sorted = detections.sortedByDescending { it.confidence }
        val selected = mutableListOf<YoloDetection>()
        for (det in sorted) {
            var keep = true
            for (chosen in selected) {
                if (det.classId == chosen.classId && calculateIoU(det.boundingBox, chosen.boundingBox) > iouThreshold) {
                    keep = false
                    break
                }
            }
            if (keep) selected.add(det)
        }
        return selected
    }

    private fun calculateIoU(a: RectF, b: RectF): Float {
        val xA = max(a.left, b.left)
        val yA = max(a.top, b.top)
        val xB = min(a.right, b.right)
        val yB = min(a.bottom, b.bottom)
        val inter = max(0f, xB - xA) * max(0f, yB - yA)
        val union = (a.width() * a.height()) + (b.width() * b.height()) - inter
        return if (union > 0f) inter / union else 0f
    }

    fun close() {
        interpreter?.close()
        gpuDelegate?.close()
    }
}