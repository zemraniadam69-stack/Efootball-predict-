package com.efootball.visionassist.overlay

import android.content.Context
import android.graphics.*
import android.view.Choreographer
import android.view.View
import com.efootball.visionassist.data.*
import com.efootball.visionassist.vision.PitchDetector
import com.efootball.visionassist.vision.VisionPipeline
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class PitchOverlayView(context: Context) : View(context), Choreographer.FrameCallback {

    private val viewScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var currentState = OverlayState()
    private var currentSettings = AssistSettings()
    private var pitchDetector: PitchDetector? = null

    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#06B6D4")
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val teammatePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3B82F6")
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val opponentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EF4444")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val bestPassGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8010B981")
        style = Paint.Style.STROKE
        strokeWidth = 16f
        maskFilter = BlurMaskFilter(12f, BlurMaskFilter.Blur.NORMAL)
    }
    private val bestPassCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#10B981")
        style = Paint.Style.STROKE
        strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND
    }
    private val secondPassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#A0F59E0B")
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun bindPipeline(pipeline: VisionPipeline) {
        this.pitchDetector = pipeline.getPitchDetector()
        viewScope.launch { pipeline.overlayState.collectLatest { currentState = it } }
        viewScope.launch { pipeline.settings.collectLatest { currentSettings = it } }
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val detector = pitchDetector ?: return
        val scaleX = width / 1280f
        val scaleY = height / 720f

        // 1. Draw Pass Lines
        if (currentSettings.showPassLines) {
            for (option in currentState.passOptions.reversed()) {
                val start = detector.pitchToScreen(option.startPitch)
                val target = detector.pitchToScreen(option.targetPitch)
                val x1 = start.x * scaleX
                val y1 = start.y * scaleY
                val x2 = target.x * scaleX
                val y2 = target.y * scaleY

                if (option.rank == 1) {
                    canvas.drawLine(x1, y1, x2, y2, bestPassGlowPaint)
                    canvas.drawLine(x1, y1, x2, y2, bestPassCorePaint)
                } else {
                    canvas.drawLine(x1, y1, x2, y2, secondPassPaint)
                }
            }
        }

        // 2. Draw Opponents
        if (currentSettings.showOpponents) {
            for (opp in currentState.opponents) {
                val screen = detector.pitchToScreen(opp.pitchPosition)
                canvas.drawCircle(screen.x * scaleX, screen.y * scaleY, 20f, opponentPaint)
            }
        }

        // 3. Draw Teammates
        for (tm in currentState.teammates) {
            val screen = detector.pitchToScreen(tm.pitchPosition)
            canvas.drawCircle(screen.x * scaleX, screen.y * scaleY, 22f, teammatePaint)
        }

        // 4. Draw Ball
        currentState.ball?.let { ball ->
            val screen = detector.pitchToScreen(ball.pitchPosition)
            canvas.drawCircle(screen.x * scaleX, screen.y * scaleY, 18f, ballPaint)
        }
    }
}