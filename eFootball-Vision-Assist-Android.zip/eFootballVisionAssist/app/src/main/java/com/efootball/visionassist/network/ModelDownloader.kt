package com.efootball.visionassist.network

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

sealed class DownloadStatus {
    object Idle : DownloadStatus()
    object Checking : DownloadStatus()
    data class Downloading(val progressPercent: Int, val bytesDownloaded: Long, val totalBytes: Long) : DownloadStatus()
    data class Success(val file: File) : DownloadStatus()
    data class Error(val message: String) : DownloadStatus()
}

class ModelDownloader(private val context: Context) {

    private val _downloadStatus = MutableStateFlow<DownloadStatus>(DownloadStatus.Idle)
    val downloadStatus = _downloadStatus.asStateFlow()

    fun getModelFile(): File = File(context.filesDir, "yolov8n.tflite")
    fun isModelReady(): Boolean = getModelFile().exists() && getModelFile().length() > 5_000_000

    suspend fun checkOrDownloadModel(forceRedownload: Boolean = false) = withContext(Dispatchers.IO) {
        val target = getModelFile()
        if (!forceRedownload && isModelReady()) {
            _downloadStatus.value = DownloadStatus.Success(target)
            return@withContext
        }
        _downloadStatus.value = DownloadStatus.Checking
        val client = OkHttpClient()
        val request = Request.Builder().url("https://huggingface.co/Ultralytics/YOLOv8/resolve/main/yolov8n.tflite").build()

        try {
            val response = client.newCall(request).execute()
            val body = response.body ?: throw Exception("Empty response body")
            val total = body.contentLength()
            val input = body.byteStream()
            val output = FileOutputStream(target)
            val buffer = ByteArray(8192)
            var read = 0L
            var bytes: Int

            while (input.read(buffer).also { bytes = it } != -1) {
                output.write(buffer, 0, bytes)
                read += bytes
                if (total > 0) {
                    _downloadStatus.value = DownloadStatus.Downloading(((read * 100) / total).toInt(), read, total)
                }
            }
            output.flush()
            output.close()
            input.close()
            _downloadStatus.value = DownloadStatus.Success(target)
        } catch (e: Exception) {
            _downloadStatus.value = DownloadStatus.Error(e.message ?: "Download failed")
        }
    }
}