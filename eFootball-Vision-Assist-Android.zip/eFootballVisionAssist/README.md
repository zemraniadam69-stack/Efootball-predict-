# eFootball Vision Assist
Complete Android Kotlin + Jetpack Compose application for real-time OpenCV + YOLOv8 pass assistance over eFootball (jp.konami.pesam).

1. Open Android Studio (Ladybug 2024.2+).
2. Click "Open Project" and select this folder.
3. Gradle will sync automatically using compileSdk 35 and NDK.
4. Run on a connected Android phone or emulator.